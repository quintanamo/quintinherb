import tweepy
import datetime
import pymysql.cursors

# Twitter API stuff
CONSUMER_KEY = '5EieAb4yQz9M5fcuDINIw6EBu'
CONSUMER_SECRET = 'K7O6FlguabVRtVxWsunvokw55VgvhbnbM6PJEB5DEMI5954uzl'
ACCESS_TOKEN_KEY = '1118143230757998593-lES7cPJ1jcYIlMeo7i25Cy2tHbXvRf'
ACCESS_TOKEN_SECRET = 'aovfvcgFjObp6bSSlWKJlxvu5RMvEyjq1WFcx7fHGi9QW'

auth = tweepy.OAuthHandler(CONSUMER_KEY, CONSUMER_SECRET)
auth.set_access_token(ACCESS_TOKEN_KEY, ACCESS_TOKEN_SECRET)
api = tweepy.API(auth)

# MySQL and MariaDB stuff
connection = pymysql.connect(
	host='localhost',
	user='beansbot',
	password='',
	db='beancountsdb',
	charset='utf8mb4',
	cursorclass=pymysql.cursors.DictCursor
	)

try:
	class MyStreamListener(tweepy.StreamListener):
                beanCounter = 0
                startDate = datetime.date.today()
		def on_status(self, status):
			if datetime.date.today() != startDate:
				newStatus = '"Beans" was tweeted',str(beanCounter),'times on',str(startDate),'.'
				api.update_status(newStatus)
                                with connection.cursor() as cursor:
                                        sql = 'INSERT INTO `counts` (`date`, `count`) VALUES (%s, %s)'
                                        cursor.execute(sql, (startDate, beanCounter))
                                connection.commit()
				self.beanCounter = 0
				self.startDate = datetime.date.today()
			self.beanCounter += 1
			try:
                                status.favorite()
                        except Exception as e:
                                print("Error:", str(e))

	myStreamListener = MyStreamListener()
	myStream = tweepy.Stream(auth=api.auth, listener=myStreamListener)

	myStream.filter(track=['beans'])
finally:
	connection.close()
