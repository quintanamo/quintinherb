Hello, my name is Quintin and I am a student at York College of Pennsylvania.
You probably don't care about that so let's get into it.

This is a quick project I threw together for my Software Engineering class. We
were tasked to find something we want to learn and learn it, so I chose Visual
Studio and C#.  This is the result.

Current features:
	- Ability to change brush colors
	- Ability to use custom colors
	- Ability to clear canvas
	- Ability to change canvas background
	- Ability to change brush size
	- Ability to save image

Known bugs:
	- Canvas may flicker slightly when updating graphics
	- Probably others but I haven't found them yet, so if
	  you do, email me at quintin@quintinherb.net.