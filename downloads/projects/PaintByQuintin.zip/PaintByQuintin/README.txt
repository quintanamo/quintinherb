#############################################################################
#############################################################################
#############################################################################

Hello, my name is Quintin and I am a student at York College of Pennsylvania.
You probably don't care about that so let's get into it.

This is a quick project I threw together for my Software Engineering class. We
were tasked to find something we want to learn and learn it, so I chose Visual
Studio and C#.  This is the result.

#############################################################################
#############################################################################
#############################################################################

Current features:
	- Change brush colors
	- Use custom colors
	- Clear canvas
	- Change canvas background
	- Change brush size
	- Change brush shape
	- save image
	- undo your actions all the way back to the first

#############################################################################

Known bugs:
	- Canvas may flicker slightly when updating graphics
	- Curser indicating brush size removed due to forced
	  graphicsl flickering
	- Probably others but I haven't found them yet, so if
	  you do, email me at quintin@quintinherb.net.

#############################################################################

Note:  This is an entirely new learning experience I have undertaken, so the
program might not run 100% perfectly.  It is a for-fun project and not meant
to be used for any hardcore basic painting, whatever that is.

#############################################################################
#############################################################################
#############################################################################